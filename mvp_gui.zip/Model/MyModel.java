package Model;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Observable;

import algorithms.mazeGenerators.Maze3DSearchable;
import algorithms.mazeGenerators.Maze3d;
import algorithms.mazeGenerators.MyMaze3dGenerator;
import algorithms.search.BFS;
import algorithms.search.DFS;
import algorithms.search.Searchable;
import algorithms.search.Searcher;
import algorithms.search.Solution;
import in.MyDecompressorInputStream;
import io.MyCompressorOutputStream;

public class MyModel extends Observable implements Model {

	private ArrayList<Thread>threads=new ArrayList<Thread>();
	private HashMap<String,Maze3d>mazes=new HashMap<String,Maze3d>();
	private HashMap<String,Solution>solutions=new HashMap<String,Solution>();
	private String message;
	
	public MyModel(){
		
	}
	
	@Override
	public Maze3d generateMaze(String name, int length, int height, int width) {
		/*Thread thread=new Thread(new Runnable(){

			@Override
			public void run() {
				MyMaze3dGenerator mg=new MyMaze3dGenerator();
				Maze3d maze3d=mg.generate(length, height, width);
				mazes.put(name,maze3d);
				message="\nMaze "+name+" is ready\n\n";
				setChanged();
				notifyObservers("displayMessage");
			}
		});
		thread.setName("GENERATE MAZE THREAD");
		thread.start();
		threads.add(thread);*/
		
		
		MyMaze3dGenerator mg=new MyMaze3dGenerator();
		Maze3d maze3d=mg.generate(length, height, width);
		mazes.put(name,maze3d);
		message="\nMaze "+name+" is ready\n\n";
		setChanged();
		notifyObservers("displayMessage");
		return maze3d;
	}

	@Override
	public void saveMaze(String mazeName, String fileName) {
		Thread thread=new Thread(new Runnable(){
			@Override
			public void run() {
				try {
					@SuppressWarnings("resource")
					MyCompressorOutputStream cmp=new MyCompressorOutputStream(new FileOutputStream(fileName+".mz"));
					cmp.write(mazes.get(mazeName).toByteArray());
					message="\nMaze "+mazeName+" saved\n\n";
					setChanged();
					notifyObservers("displayMessage");
					
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				} catch (UnsupportedEncodingException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}	
		}) ;
		thread.setName("SAVE MAZE THREAD");
		thread.start();
		threads.add(thread);
	}

	@Override
	public void loadMaze(String fileName, String mazeName) {
		Thread thread=new Thread(new Runnable(){
			@Override
			public void run() {
				boolean fileLoaded=false;
				File f = new File(System.getProperty("user.dir"));
				File[] filesInDirectory = f.listFiles();
				for(int i=0;i<filesInDirectory.length;i++)
				{
					if(filesInDirectory[i].getName().equals(fileName)==true)
					{
						try {
							@SuppressWarnings("resource")
							MyDecompressorInputStream dcmp=new MyDecompressorInputStream(new FileInputStream(filesInDirectory[i]));
							int fileSize=(int)(filesInDirectory[i].length()*5);
							byte[]b=new byte[fileSize];
							dcmp.read(b);
							Maze3d maze=new Maze3d(b);
							mazes.put(mazeName, maze);
							message="\nMaze "+mazeName+ " loaded\n\n";
							setChanged();
							notifyObservers("displayMessage");
							fileLoaded=true;
						} catch (FileNotFoundException e) {
							e.printStackTrace();
						} catch (IOException e) {
							e.printStackTrace();
						}
						break;
					}	
				}
				if(fileLoaded==false)
				{
					message="\n!!!The file "+fileName+ " can't be loaded!!!\n\n";
					setChanged();
					notifyObservers("displayMessage");
				}
			}
		});
		thread.setName("LOAD MAZE THREAD");
		thread.start();
		threads.add(thread);
	}

	@Override
	public String getMessage() {
		return message;
	}

	@Override
	public Maze3d getMaze(String mazeName) {
		return mazes.get(mazeName);
	}

	@Override
	public double getFileSize(String fileName) {
		File f = new File(System.getProperty("user.dir"));
		File[] filesInDirectory = f.listFiles();
		for(int i=0;i<filesInDirectory.length;i++)
		{
			if(filesInDirectory[i].getName().equals(fileName)==true)
			{
				return filesInDirectory[i].length();
			}	
		}
		return -1;
	}

	@Override
	public int getMazeSize(String mazeName) {
		Maze3d maze=mazes.get(mazeName);
		if(maze==null)
		{
			return -1;
		}
		else
		{
			int totalSize=maze.getHeight()*maze.getLength()*maze.getWidth()*4;
			return totalSize;
		}
	}

	@Override
	public String[] getFilesList(String directory) {
		
		Path path = FileSystems.getDefault().getPath(directory);
		
		if (Files.exists(path)) {
			File folder = new File(directory);
			File[] listOfFiles = folder.listFiles();
			String[] filesList=new String[listOfFiles.length];
		
			int i=0;
			for (File file : listOfFiles)
			{  
				filesList[i]=file.getName();
		    i++;
		    }
			return filesList;
		}
		else
		{
			return null;
		}
	}

	@Override
	public Solution solveMaze(String mazeName, String algrorithmName) {
		/*Thread thread=new Thread(new Runnable(){
			@Override
			public void run() {
				Maze3d maze=mazes.get(mazeName);
				Solution solution=null;
				if(algrorithmName.equals("bfs")==true)
				{
					solution=testSearcher(new BFS(), new Maze3DSearchable(maze));
				}
				if(algrorithmName.equals("dfs")==true)
				{
					solution=testSearcher(new DFS(), new Maze3DSearchable(maze));
				}
				message="\nThe maze "+mazeName+" has been solved\n\n";
				setChanged();
				notifyObservers("displayMessage");
				solutions.put(mazeName, solution);
			}
		});
		thread.start();
		thread.setName("SOLVE MAZE THREAD");
		threads.add(thread);*/
		
		
		Maze3d maze=mazes.get(mazeName);
		Solution solution=null;
		if(algrorithmName.equals("bfs")==true)
		{
			solution=testSearcher(new BFS(), new Maze3DSearchable(maze));
		}
		if(algrorithmName.equals("dfs")==true)
		{
			solution=testSearcher(new DFS(), new Maze3DSearchable(maze));
		}
		message="\nThe maze "+mazeName+" has been solved\n\n";
		setChanged();
		notifyObservers("displayMessage");
		solutions.put(mazeName, solution);
		return solution;
	}
	
	@SuppressWarnings("rawtypes")
	private Solution testSearcher(Searcher searcher, Searchable searchable){
		 Solution solution=searcher.Search(searchable);
		 return solution;
	}

	@Override
	public Solution getSolution(String mazeName) {
		Solution solution=solutions.get(mazeName);
		return solution;
	}

	@Override
	public boolean mazeExists(String mazeName) {
		if(mazes.get(mazeName)!=null)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
