package Presenter;

public class ExitCommand implements Command {

	Presenter presenter;
	
	public ExitCommand(Presenter presenter)
	{
		this.presenter=presenter;
	}
	
	@Override
	public void doCommand(String[] args) {
		presenter.shutdownExecutor();
	}

}
