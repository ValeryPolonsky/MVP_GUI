package Presenter;

import Model.Model;
import View.View;

public class FileSizeCommand implements Command {

	Model model;
	View view;
	
	public FileSizeCommand(Model model,View view){
		this.view=view;
		this.model=model;
	}
	
	@Override
	public void doCommand(String[] args) {
		
		if(args.length!=1)
		{
			view.displayMessage("\n!!!Wrong number of arguments!!!\n\n");
			return;
		}
		
		double fileSize=model.getFileSize(args[0]);
		if(fileSize==-1)
		{
			view.displayMessage("\n!!!The file "+args[0]+" doesn't exist!!!\n\n");
			return;
		}
		
		String message="\nThe size of file "+args[0]+" is "+fileSize+" bytes\n\n";
		view.displayMessage(message);
	}
}
