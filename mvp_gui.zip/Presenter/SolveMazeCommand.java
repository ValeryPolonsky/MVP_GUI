package Presenter;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;

import Model.Model;
import View.View;
import algorithms.search.Solution;

public class SolveMazeCommand implements Command {

	Model model;
	View view;
	ExecutorService executor;
	
	public SolveMazeCommand(Model model,View view,ExecutorService executor)
	{
		this.model=model;
		this.view=view;
		this.executor=executor;
	}
	@Override
	public void doCommand(String[] args) {
		
		if(args.length!=2)
		{
			view.displayMessage("\n!!!Wrong number of arguments!!!\n\n");
			return;
		}
		
		if(!model.mazeExists(args[0]))
		{
			view.displayMessage("\n!!!The maze "+args[0]+" doesn't exist!!!\n\n");
			return;
		}
		
		if(!args[1].equals("bfs")&&!args[1].equals("dfs"))
		{
			view.displayMessage("\n!!!The algorithm "+args[1]+" doesn't exist!!!\n\n");
			return;
		}
		
		Callable<Solution>callable=new SolveMazeCallable(model,args[0],args[1]);
		@SuppressWarnings("unused")
		Future<Solution>future=executor.submit(callable);
	}
}
