package algorithms.mazeGenerators;

/**
 * Interface needed to create different types of mazes
 * @author Valery Polonsky
 *
 */
public interface Maze {
	
}
